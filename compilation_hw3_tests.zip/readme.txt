In order to run the tests just copy your executable to this folder, and run the script run_tests.
The script gets 1 input, which is which tests to run (basic, full, unstable).
The unstable test directory contains enums, which are not implemented in our version of the hw.
Dont forget to chmod +x run_tests.
Good luck :)
